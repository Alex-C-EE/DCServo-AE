/* motor_control.c */

#include "motor_control.h"
#include "main.h"  // Contains handles for htim2 and hadc1

/* Declare external variables */
extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim2;

/* Private variables */
static float currentDutyCycle = 0.0f;
static Motor_Direction_t currentDirection = MOTOR_STOP;

/* Private function prototypes */
static void UpdatePWMOutputs(void);

/* Public functions */

/**
 * @brief  Initializes the motor control module.
 * @retval None
 */
void Motor_Init(void) {
    // Start PWM channels
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);  // CH1
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);  // CH2

    // Initialize ADC for current sensing
    HAL_ADC_Start(&hadc1);

    // Set initial motor state
    Motor_Stop();
}

/**
 * @brief  Sets the motor direction.
 * @param  direction: MOTOR_FORWARD, MOTOR_BACKWARD, MOTOR_BRAKE, or MOTOR_STOP
 * @retval None
 */
void Motor_SetDirection(Motor_Direction_t direction) {
    currentDirection = direction;
    UpdatePWMOutputs();
}

/**
 * @brief  Sets the motor duty cycle.
 * @param  dutyCycle: Value between 0.0 (0%) and 1.0 (100%)
 * @retval None
 */
void Motor_SetDutyCycle(float dutyCycle) {
    if (dutyCycle < 0.0f) dutyCycle = 0.0f;
    if (dutyCycle > 1.0f) dutyCycle = 1.0f;
    currentDutyCycle = dutyCycle;
    UpdatePWMOutputs();
}

/**
 * @brief  Gets the motor current by reading the ADC.
 * @retval Current in amperes (or voltage proportional if calibration is needed)
 */
float Motor_GetCurrent(void) {
    HAL_ADC_Start(&hadc1);
    if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK) {
        uint32_t adcValue = HAL_ADC_GetValue(&hadc1);
        float voltage = (adcValue / 4095.0f) * 3.3f;  // Assuming 12-bit ADC and 3.3V reference
        return voltage;
    } else {
        // Handle ADC read error
        return -1.0f;  // Indicate an error
    }
}

/**
 * @brief  Stops the motor.
 * @retval None
 */
void Motor_Stop(void) {
    currentDutyCycle = 0.0f;
    currentDirection = MOTOR_STOP;
    UpdatePWMOutputs();
}

/* Private functions */

/**
 * @brief  Updates the PWM outputs based on the current duty cycle and direction.
 * @retval None
 */
static void UpdatePWMOutputs(void) {
    uint32_t pulseValue = (uint32_t)(currentDutyCycle * (__HAL_TIM_GET_AUTORELOAD(&htim2) + 1));

    switch (currentDirection) {
        case MOTOR_FORWARD:
            // CH1 active, CH2 inactive
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pulseValue);
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 0);
            break;

        case MOTOR_BACKWARD:
            // CH2 active, CH1 inactive
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulseValue);
            break;

        case MOTOR_BRAKE:
            // Both CH1 and CH2 active
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pulseValue);
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulseValue);
            break;

        case MOTOR_STOP:
        default:
            // Both channels inactive
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);
            __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 0);
            break;
    }
}
