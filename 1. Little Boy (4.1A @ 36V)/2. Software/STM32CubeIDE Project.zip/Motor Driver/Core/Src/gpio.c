/* gpio.c */
#include "gpio.h"
#include "stm32g0xx_hal.h"

void GPIO_Init(void){
	// Enable GPIO Ports
	__HAL_ECC_GPIOA_CLK_ENABLE();
	__HAL_ECC_GPIOB_CLK_ENABLE();

	// Configure GPIO Pins

    GPIO_InitStruct.Pin = GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;   // Push-pull output
    GPIO_InitStruct.Pull = GPIO_NOPULL;           // No pull-up or pull-down resistors
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;  // Low frequency
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;   // Push-pull output
    GPIO_InitStruct.Pull = GPIO_NOPULL;           // No pull-up or pull-down resistors
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;  // Low frequency
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
