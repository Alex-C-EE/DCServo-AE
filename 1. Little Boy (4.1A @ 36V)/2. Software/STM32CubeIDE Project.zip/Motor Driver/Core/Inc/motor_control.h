/* motor_control.h */

#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include "stm32g0xx_hal.h"

/* Enumeration for motor direction */
typedef enum {
    MOTOR_STOP = 0,
    MOTOR_FORWARD,
    MOTOR_BACKWARD,
    MOTOR_BRAKE
} Motor_Direction_t;

/* Function prototypes */
void Motor_Init(void);
void Motor_SetDirection(Motor_Direction_t direction);
void Motor_SetDutyCycle(float dutyCycle);  // dutyCycle: 0.0 to 1.0
float Motor_GetCurrent(void);
void Motor_Stop(void);

#endif // MOTOR_CONTROL_H
