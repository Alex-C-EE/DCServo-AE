/*
 * can.h
 *
 *  Created on: Oct 15, 2024
 *      Author: const
 */

// Handle low-level CAN communication details.

#ifndef INC_CAN_H_
#define INC_CAN_H_



#endif /* INC_CAN_H_ */
