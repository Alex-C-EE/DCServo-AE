/*
 * spi.h
 *
 *  Created on: Oct 15, 2024
 *      Author: const
 */

#ifndef INC_SPI_H_
#define INC_SPI_H_



#endif /* INC_SPI_H_ */
