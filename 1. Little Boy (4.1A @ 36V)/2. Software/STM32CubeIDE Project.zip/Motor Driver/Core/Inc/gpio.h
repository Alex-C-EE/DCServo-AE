/*
 * gpio.h
 */

#ifndef INC_GPIO_H_
#define INC_GPIO_H_

#include "stm32g0xx_hal.h"

void GPIO_Init(void);

#endif /* INC_GPIO_H_ */
