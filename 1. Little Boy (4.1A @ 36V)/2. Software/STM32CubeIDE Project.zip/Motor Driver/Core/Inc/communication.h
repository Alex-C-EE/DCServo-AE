/*
 * communication.h
 *
 *  Created on: Oct 15, 2024
 *      Author: const
 */

#ifndef INC_COMMUNICATION_H_
#define INC_COMMUNICATION_H_



#endif /* INC_COMMUNICATION_H_ */
